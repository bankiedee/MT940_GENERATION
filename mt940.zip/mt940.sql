/* Formatted on 2018/08/23 19:31 (Formatter Plus v4.8.8) */
--######################################################################################################################
--#     Report Name             :  MT940 FOR DANGOTE
--#     File Name               :  mt940.sql
--#     Maintained by           :  UBA Bank
--#     Calling Script          :
--#     Date                    :
--#     Author                  :
--#     Input Parameters        :  
--#     Assumptions/Exception   :
--#     Modification History    :
--#        <Serial No.>          <Date>                 <Author Name>                               <Description>
-->         000                   29-098-2014        Mojeed Oladunjoye                          Header and Bankid
--#######################################################################################################################
SET head off
SET trims on
SET wrap off
SET head off
SET wrap off
SET feedback off
SET trim on
SET echo off
SET verify off
SET termout off
SET lines 255
SET pagesize 0
SET numformat 9999999999999.99
SET Serveroutput on size 1000000

SPOOL swmt940.lst

BEGIN
   DECLARE
      facid              VARCHAR2 (35)                     := '&1';
      v_foracid          VARCHAR2 (35);
      sdate              tbaadm.dctd_acli.tran_date%TYPE
                                              := TO_DATE ('&3', 'DD-MM-YYYY');
      edate              tbaadm.dctd_acli.tran_date%TYPE
                                              := TO_DATE ('&4', 'DD-MM-YYYY');
      sum_tran           tbaadm.dctd_acli.tran_amt%TYPE    := 0;
      final_clsn         tbaadm.dctd_acli.tran_amt%TYPE    := 0;
      t_refno            VARCHAR2 (16)                     := '&1';
      seq_no             VARCHAR2 (5)                      := '00000';
      seq_date           VARCHAR2 (5);
      recvbic            VARCHAR2 (16)                     := '&2';
      recvbrcd           VARCHAR2 (3)                      := '';
      account_id         VARCHAR2 (10)                     := '';
      opn_bal            VARCHAR2 (255)                    := '';
      counta             NUMBER (2)                        := 0;
      pg_count           NUMBER (5)                        := 1;
--pg_count   number ;
      clsn_bal           VARCHAR2 (255)                    := '';
      clsn_bal64         VARCHAR2 (255)                    := '';
      tran_type          VARCHAR2 (1);
      crncy_code         tbaadm.gam.acct_crncy_code%TYPE;
      acctcrncy          tbaadm.gam.acct_crncy_code%TYPE;
      today              DATE;
      tmp_seq_date       DATE;
      value_date         DATE;
      entry_date         DATE;
      eff_sum_bal        tbaadm.dctd_acli.tran_amt%TYPE    := 0;
      acctold            tbaadm.gam.foracid%TYPE;
---acct_report_type     mt940acct.report_type%type;
      acct_report_type   VARCHAR2 (10);
      v_length_86        NUMBER (20, 2);
      v_stmt1            VARCHAR2 (255)                    := '';
      v_stmt2            VARCHAR2 (255)                    := '';
      v_newstmt_line     VARCHAR2 (255)                    := '';
----stmt_line_86         varchar2(255)      :='';
      stmt_line_86       VARCHAR2 (255);
      check1             VARCHAR2 (80);
      check2             VARCHAR2 (10);
      rnum               VARCHAR2 (15);
      rtrid              VARCHAR2 (15);
      rtid               VARCHAR2 (15);
      rcod               VARCHAR2 (80);
      v_stmt_line_61     VARCHAR2 (80);
      v_newt_line_86     VARCHAR2 (80);
      v_tran_id          VARCHAR2 (15);

--d_stmt_line_61           varchar2(80);
      CURSOR cs
      IS
         SELECT tran_amt each_tran_amt, part_tran_type, value_date,
                entry_date, tran_type, tran_sub_type, a.acid, foracid,
                tran_id,
                   ':61:'
                || TO_CHAR (value_date, 'YYMMDD')
                || TO_CHAR (entry_date, 'MMDD')
                || part_tran_type
                || SUBSTR (a.tran_crncy_code, 3, 1)
                || TO_CHAR (FLOOR (tran_amt))
                || ','
                || LPAD (TO_CHAR ((tran_amt - FLOOR (tran_amt)) * 100), 2,
                         '0')
                || 'N'
                || DECODE (a.ref_num,
                           'CSH', 'TRF',
                           'CHK', 'COM',
                           'DDT', 'DDT',
                           'CHG', 'RTI',
                           'STO', 'LDP',
                           'INT', 'COL',
                           'MSC'
                          )
                || SUBSTR (NVL (REPLACE (REGEXP_REPLACE (tran_particular,
                                                         '[^0-9A-Za-z/$]',
                                                         ' '
                                                        ),
                                         '$',
                                         'USD'
                                        ),
                                '.'
                               ),
                           1,
                           16
                          )
                || '//'
                || TRIM (a.tran_id) stmt_line_61,
                   ':86:'
                || SUBSTR (NVL (REPLACE (REGEXP_REPLACE (tran_particular,
                                                         '[^0-9A-Za-z/$]',
                                                         ' '
                                                        ),
                                         '$',
                                         'USD'
                                        ),
                                '.'
                               ),
                           1,
                           65
                          ) stmt_line_86
           FROM tbaadm.dctd_acli a, tbaadm.gam b
          WHERE a.acid = b.acid
            AND b.foracid = facid
            AND a.del_flg != 'Y'
            AND acct_cls_flg != 'Y'
            AND a.bank_id = '&5'
            AND b.bank_id = '&5'
            AND tran_date BETWEEN sdate AND edate
            AND NOT EXISTS (
                   SELECT 'X'
                     FROM tbaadm.atd e
                    WHERE a.tran_id = e.tran_id
                      AND a.tran_date = e.tran_date
                      AND e.tran_date = edate
                      AND e.bank_id = '&5');

                CURSOR c_recvbic
      IS
         SELECT bic_code
           FROM custom.mt940acct
          WHERE foracid = facid AND bic_code = recvbic;             
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
   BEGIN
--MT 940 Swift messages Header
---This was adjusted for receiver BIC code from 10 to 11 on 070706 by princewill
--dbms_output.put_line ('{1:F01UNAFNGLAAXXX1234123456}{2:I940' || substr(recvBIC,1,12) || 'N}{4:');
      BEGIN
         OPEN c_recvbic;

         LOOP
            FETCH c_recvbic
             INTO recvbic;

            EXIT WHEN c_recvbic%NOTFOUND;
         END LOOP;

         CLOSE c_recvbic;
      DBMS_OUTPUT.put_line (   '{1:F01UNAFTZTZAXXX1234123456}{2:I940'
                            || SUBSTR (recvbic, 1, 12)
                            || 'N}{4:'
                           );

--
--### This is to address the requirement to report old account numbers for NUBAN for MOBIL
--######This adjustment was made by Princewill C Opara on June 03,2011

      END;

--MT 940 Tag 20 - Transaction reference number
--

         DBMS_OUTPUT.put_line (':20:' || t_refno);


---dbms_output.put_line (':20:'|| t_refno);
--
-- 940 Tag 25 - Account Identification
--

         DBMS_OUTPUT.put_line (':25:' || facid);


---dbms_output.put_line (':25:'|| facid);
--
--
-- To declare and select currency for opening balances when NULL data found in EAB table this was added 02102007
     BEGIN
         SELECT acct_crncy_code
           INTO acctcrncy
           FROM tbaadm.gam
          WHERE foracid = facid AND bank_id = '&5';
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            NULL;
      END;

--MT 940 Tag 60f - Opening Balance

      --This was corrected on Sept 28 2007 for NULL value when there is no records in EAB.It was noticed during implementation of
---MT940 for Mercuria Oil Trading that messages fail Swift validation when there is no opening balance due to no prior balance
--In EAB.

      BEGIN
         SELECT b.acid, tran_date_bal, value_date_bal, acct_crncy_code,
                   ':60F:'
                || DECODE (SIGN (tran_date_bal), -1, 'D', 'C')
                || TO_CHAR (TO_DATE (sdate), 'YYMMDD')
                || acct_crncy_code
                || TO_CHAR (FLOOR (ABS (tran_date_bal)))
                || ','
                || LPAD (TO_CHAR (  (  ABS (tran_date_bal)
                                     - FLOOR (ABS (tran_date_bal))
                                    )
                                  * 100
                                 ),
                         2,
                         '0'
                        )
           INTO account_id, sum_tran, eff_sum_bal, crncy_code,
                opn_bal
           FROM tbaadm.eab a, tbaadm.gam b
          WHERE a.acid = b.acid
            AND b.foracid = facid
            AND a.bank_id = '&5'
            AND b.bank_id = '&5'
            AND eod_date <= TO_DATE (sdate) - 1
            AND end_eod_date >= TO_DATE (sdate) - 1;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            sum_tran := 0;
            eff_sum_bal := 0;
            opn_bal :=
                  ':60F:'
               || 'C'
               || TO_CHAR (TO_DATE (sdate), 'YYMMDD')
               || acctcrncy
               || 0
               || ','
               || 0
               || 0;
      END;

--MT 940 Tag 28 - Statement number
      BEGIN
         SELECT free_code_9, NVL (free_code_10, '00000')
           INTO seq_date, seq_no
           FROM tbaadm.gac
          WHERE acid = account_id AND bank_id = '&5';
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            NULL;
      END;

      SELECT SYSDATE
        INTO today
        FROM DUAL;

--Initialised for today's date
      seq_date := TO_CHAR (today, 'DDMON');

      IF (seq_no = '99999')
      THEN
         seq_no := '00001';
         seq_date := TO_CHAR (today, 'DDMON');
      ELSE
         seq_no := TO_NUMBER (seq_no) + 1;
         tmp_seq_date :=
                   TO_DATE (seq_date || TO_CHAR (today, 'YYYY'), 'DDMONYYYY');

         IF (today - tmp_seq_date >= 364)
         THEN
            seq_date := TO_CHAR (today, 'DDMON');
            seq_no := '00001';
         END IF;
      END IF;

      seq_no := LPAD (seq_no, 5, '0');
      DBMS_OUTPUT.put_line (   ':28C:'
                            || seq_no
                            || '/'
                            || LPAD (TO_CHAR (pg_count), 2, '0')
                           );
--
--MT 940 Tag 60f - Opening Balance
      DBMS_OUTPUT.put_line (opn_bal);

      BEGIN
         SELECT tran_date_bal
           INTO final_clsn
           FROM tbaadm.eab a, tbaadm.gam b
          WHERE a.acid = b.acid
            AND b.foracid = facid
            AND a.bank_id = '&5'
            AND b.bank_id = '&5'
            AND a.eod_date <= (edate)
            AND a.eod_date =
                   (SELECT MAX (eod_date)
                      FROM tbaadm.eab e1
                     WHERE e1.acid = a.acid
                       AND e1.bank_id = '&5'
                       AND e1.eod_date <= (edate));
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            NULL;
      END;

--
--MT 940 Tag 61 - Statement line
--
      FOR e IN cs
      LOOP
         v_tran_id := TRIM (e.tran_id);
         counta := counta + 1;
         
       --DBMS_OUTPUT.put_line (e.STMT_LINE_61);

         IF counta = 18
         THEN
            BEGIN
               --MT 940 Tag 62 - Closing Balance
               IF sum_tran >= 0
               THEN
                  tran_type := 'C';
               ELSE
                  tran_type := 'D';
               END IF;

               ---This was addeded to show line62F per page of the message
               clsn_bal :=
                     ':62M:'
                  || tran_type
                  || TO_CHAR (TO_DATE (edate), 'YYMMDD')
                  || crncy_code
                  || TO_CHAR (FLOOR (ABS (sum_tran)))
                  || ','
                  || LPAD (TO_CHAR (  ((ABS (sum_tran)
                                        - FLOOR (ABS (sum_tran))
                                       )
                                      )
                                    * 100
                                   ),
                           2,
                           '0'
                          );
                DBMS_OUTPUT.put_line (e.STMT_LINE_61);
               DBMS_OUTPUT.put_line (clsn_bal);
               

--  #######This was added to show Line 64 on each page of message when there are multiple messages done by princewill
               IF eff_sum_bal >= 0
               THEN
                  tran_type := 'C';
               ELSE
                  tran_type := 'D';
               END IF;

               clsn_bal64 :=
                     ':64:'
                  || tran_type
                  || TO_CHAR (TO_DATE (edate), 'YYMMDD')
                  || crncy_code
                  || TO_CHAR (FLOOR (ABS (eff_sum_bal)))
                  || ','
                  || LPAD (TO_CHAR (  ((  ABS (eff_sum_bal)
                                        - FLOOR (ABS (eff_sum_bal))
                                       )
                                      )
                                    * 100
                                   ),
                           2,
                           '0'
                          );
               DBMS_OUTPUT.put_line (clsn_bal64);
               --
               --MT 940 Statement Close
               --
               DBMS_OUTPUT.put_line ('-}');
--******** Generate new statement
--dbms_output.put_line ('/');
--MT 940 Swift messages Header
               DBMS_OUTPUT.put_line (   '{1:F01UNAFTZTZAXXX1234123456}{2:I940'
                                     || SUBSTR (recvbic, 1, 12)
                                     || 'N}{4:'
                                    );

--MT 940 Tag 20 - Transaction reference number
--### This is to address the requirement to report old account numbers for NUBAN for MOBIL
--######This adjustment was made by Princewill C Opara on June 03,2011
               BEGIN
                  SELECT free_text, report_type
                    INTO acctold, acct_report_type
                    FROM tbaadm.gam gam, custom.mt940acct mt
                   WHERE gam.foracid = mt.foracid
                     AND gam.foracid = facid
                     AND gam.bank_id = '&5'
                     AND mt.bank_id = '&5'
                     AND bic_code = recvbic;
               EXCEPTION
                  WHEN NO_DATA_FOUND
                  THEN
                     NULL;
               END;

---
               IF (acct_report_type = 'OLD')
               THEN
                  DBMS_OUTPUT.put_line (':20:' || acctold);
               ELSE
                  DBMS_OUTPUT.put_line (':20:' || t_refno);
               END IF;

--dbms_output.put_line (':20:'|| t_refno);
--
--MT 940 Tag 25 - Account Identification
--
--### The DBMS output is logically derived to accomodate old account number for Mobil on directive from ED-GCOO
--####This adjustment was made by Princewill C Opara on June 03,2011
               IF (acct_report_type = 'OLD')
               THEN
                  DBMS_OUTPUT.put_line (':25:' || acctold);
               ELSE
                  DBMS_OUTPUT.put_line (':25:' || facid);
               END IF;

----dbms_output.put_line (':25:'|| facid);
--
--MT 940 Tag 28 - Statement number
               pg_count := pg_count + 1;
               DBMS_OUTPUT.put_line (   ':28C:'
                                     || seq_no
                                     || '/'
                                     || LPAD (TO_CHAR (pg_count), 2, '0')
                                    );

               --

               -- Added by COKER to replace finacle tran id with dangote generated tranid 03-03-2018
               IF (e.acid = 'CC26318')
               THEN
                  DBMS_OUTPUT.put_line (e.acid);

                  BEGIN
                     SELECT *
                       INTO rnum, rtrid, rtid, rcod
                       FROM (SELECT LENGTH (a.ref_num), a.ref_num,
                                    TRIM (a.tran_id),
                                       a.ref_num
                                    || '-'
                                    || REGEXP_REPLACE (cust_name,
                                                       '[^0-9A-Za-z/$]',
                                                       ' '
                                                      )
                                    || '-'
                                    || cust_code
                               FROM custom.dgatctt a, tbaadm.dtd b
                              WHERE a.pstd_flg = 'Y'
                                AND TRIM (a.tran_id) = TRIM (b.tran_id)
                                AND a.lchg_time = b.tran_date
                                AND a.lchg_time =
                                         TO_DATE ('&3', 'dd-mm-yyyy')
                                AND part_tran_type = 'C'
                                AND TRIM (a.tran_id) = TRIM (v_tran_id)
                             UNION
                             SELECT LENGTH (d_tran_id), d_tran_id,
                                    TRIM (a.tran_id),
                                       d_tran_id
                                    || '-'
                                    || REGEXP_REPLACE (payee_name,
                                                       '[^0-9A-Za-z/$]',
                                                       ' '
                                                      )
                                    || '-'
                                   || customer_code
                               FROM custom.dgotedets a, tbaadm.dtd b
                             WHERE a.pstd_flg = 'Y'
                                AND TRIM (a.tran_id) = TRIM (b.tran_id)
                                AND a.tran_date = b.tran_date
                                AND a.cr_acct_no = '56010030005785'
                                AND a.tran_date =
                                         TO_DATE ('&3', 'dd-mm-yyyy')
                                AND part_tran_type = 'C'
                                AND TRIM (a.tran_id) = TRIM (v_tran_id));
                  EXCEPTION
                     WHEN NO_DATA_FOUND
                     THEN
                        rnum := 0;
                        NULL;
                  END;

                  IF (rnum > 0)
                  THEN
                     ---this part is added by coker to replace part of the tran particular with the reference from dangote 20-03-2018
                     v_stmt1 :=
                        SUBSTR (SUBSTR ((e.stmt_line_61),
                                        INSTR (e.stmt_line_61, 'NMSC') + 4
                                       ),
                                1,
                                  INSTR ((SUBSTR ((e.stmt_line_61),
                                                    INSTR (e.stmt_line_61,
                                                           'NMSC'
                                                          )
                                                 + 4
                                                 )
                                         ),
                                         '//'
                                        )
                                - 1
                               );
                     v_stmt2 := REPLACE (e.stmt_line_61, v_stmt1, rtrid);
                     v_stmt_line_61 := REPLACE (v_stmt2, rtid, rtrid);
                  --v_stmt_line_61:= 'WALE';
                        ----end change 20-03-2018-------------
                  ELSE
                     ---e.stmt_line_86 :=e.stmt_line_86;
                     ---dbms_output.put_line ('86:'||e.stmt_line_86);
                     v_stmt_line_61 := e.stmt_line_61;
                  --v_stmt_line_61:=  'DIPO' ;
                  END IF;
               END IF;

        ---END ADD  03-03-2018
     --
--MT 940 Tag 60f - Opening Balance
     --
               IF sum_tran >= 0
               THEN
                  tran_type := 'C';
               ELSE
                  tran_type := 'D';
               END IF;

               opn_bal :=
                     ':60M:'
                  || tran_type
                  || TO_CHAR (TO_DATE (sdate), 'YYMMDD')
                  || crncy_code
                  || TO_CHAR (FLOOR (ABS (sum_tran)))
                  || ','
                  || LPAD (TO_CHAR (  ((ABS (sum_tran)
                                        - FLOOR (ABS (sum_tran))
                                       )
                                      )
                                    * 100
                                   ),
                           2,
                           '0'
                          );
               DBMS_OUTPUT.put_line (opn_bal);
               counta := 1;
            END;
         END IF;

         tran_type := e.part_tran_type;
         value_date := e.value_date;
         entry_date := e.entry_date;

         IF tran_type = 'C'
         THEN
            sum_tran := sum_tran + e.each_tran_amt;
         ELSIF tran_type = 'D'
         THEN
            sum_tran := sum_tran - e.each_tran_amt;
         END IF;

--dbms_output.put_line(' tran '||e.each_tran_amt);
--dbms_output.put_line('sum_tran '||sum_tran);
--dbms_output.put_line('before IF '||eff_sum_bal);
         IF     tran_type = 'C'
            AND TO_CHAR (value_date, 'dd-mm-yyyy') =
                                            TO_CHAR (entry_date, 'dd-mm-yyyy')
         THEN
            eff_sum_bal := eff_sum_bal + e.each_tran_amt;
         ELSIF     tran_type = 'D'
               AND TO_CHAR (value_date, 'dd-mm-yyyy') =
                                            TO_CHAR (entry_date, 'dd-mm-yyyy')
         THEN
            eff_sum_bal := eff_sum_bal - e.each_tran_amt;
         END IF;

-- Added by COKER to replace finacle tran id with dangote generated tranid 03-03-2018
        IF (e.acid = 'CC26318')
         THEN
            BEGIN
               SELECT *
                 INTO rnum, rtrid, rtid, rcod
                 FROM (SELECT LENGTH (a.ref_num), a.ref_num, TRIM (a.tran_id),
                                 a.ref_num
                              || '-'
                              || REGEXP_REPLACE (cust_name,
                                                 '[^0-9A-Za-z/$]',
                                                 ' '
                                                )
                              || '-'
                              || cust_code
                         FROM custom.dgatctt a, tbaadm.dtd b
                        WHERE a.pstd_flg = 'Y'
                          AND TRIM (a.tran_id) = TRIM (b.tran_id)
                          AND a.lchg_time = b.tran_date
                          AND a.lchg_time =
                                         TO_DATE ('&3', 'dd-mm-yyyy')
                          AND part_tran_type = 'C'
                          AND TRIM (a.tran_id) = TRIM (v_tran_id)
                       UNION
                       SELECT LENGTH (d_tran_id), d_tran_id, TRIM (a.tran_id),
                                 d_tran_id
                              || '-'
                              || REGEXP_REPLACE (payee_name,
                                                 '[^0-9A-Za-z/$]',
                                                 ' '
                                                )
                              || '-'
                              || customer_code
                         FROM custom.dgotedets a, tbaadm.dtd b
                        WHERE a.pstd_flg = 'Y'
                          AND TRIM (a.tran_id) = TRIM (b.tran_id)
                          AND a.tran_date = b.tran_date
                          AND a.cr_acct_no = '56010030005785'
                          AND a.tran_date =
                                         TO_DATE ('&3', 'dd-mm-yyyy')
                          AND part_tran_type = 'C'
                          AND TRIM (a.tran_id) = TRIM (v_tran_id));
            EXCEPTION
               WHEN NO_DATA_FOUND
               THEN
                  rnum := 0;
                  NULL;
            END;

            IF (rnum > 0)
            THEN
               ---this part is added by coker to replace part of the tran particular with the reference from dangote 20-03-2018
               v_stmt1 :=
                  SUBSTR (SUBSTR ((e.stmt_line_61),
                                  INSTR (e.stmt_line_61, 'NMSC') + 4
                                 ),
                          1,
                            INSTR ((SUBSTR ((e.stmt_line_61),
                                            INSTR (e.stmt_line_61, 'NMSC') + 4
                                           )
                                   ),
                                   '//'
                                  )
                          - 1
                         );
               v_stmt2 := REPLACE (e.stmt_line_61, v_stmt1, rtrid);
               v_stmt_line_61 := REPLACE (v_stmt2, rtid, rtrid);
            --v_stmt_line_61:= 'WALE';
                ----end change 20-03-2018-------------
            ELSE
               ---e.stmt_line_86 :=e.stmt_line_86;
               ---dbms_output.put_line ('86:'||e.stmt_line_86);
               v_stmt_line_61 := e.stmt_line_61;
            --v_stmt_line_61:=  'DIPO' ;
            END IF;
         END IF;

        ---END ADD  03-03-2018
--dbms_output.put_line('after IF '||eff_sum_bal);
--dbms_output.put_line (e.stmt_line_61);
--dbms_output.put_line (e.stmt_line_86);
         DBMS_OUTPUT.put_line (v_stmt_line_61);

--dbms_output.put_line (':61'||v_stmt_line_61);

         -- Added by COKER to change the NARRATION to dangote FORMATTED NARRATION 03032018
         BEGIN
            SELECT LENGTH (e.stmt_line_86), e.acid
              INTO v_length_86, v_foracid
              FROM DUAL;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               v_length_86 := 0;
         END;

         IF (v_foracid != 'CC26318')
         THEN
            --    IF (v_length_86<9) THEN
            --           dbms_output.put_line (':86:'||e.v_newstmt_line);
            --       ELSE
            DBMS_OUTPUT.put_line (SUBSTR (e.stmt_line_86, 1, 65));
         --    END IF;
         END IF;

         IF (v_foracid = 'CC26318')
         THEN
            IF (rnum > 0)
            THEN
               DBMS_OUTPUT.put_line (':86:' || rcod);
            ELSE
                   ---    IF (v_length_86<9) THEN
                   --    dbms_output.put_line (':86:'||e.v_newstmt_line);
               --    ELSE
               DBMS_OUTPUT.put_line (SUBSTR (e.stmt_line_86, 1, 65));
            --    END IF;
            END IF;
         END IF;
      ----END ADD    03032018
      END LOOP;

--
--MT 940 Tag 62 - Closing Balance
--
      BEGIN
         SELECT    ':62F:'
                || DECODE (SIGN (NVL (tran_date_bal, 0)), -1, 'D', 'C')
                || TO_CHAR (TO_DATE (edate), 'YYMMDD')
                || acct_crncy_code
                || TO_CHAR (FLOOR (ABS (sum_tran)))
                || ','
                || LPAD (TO_CHAR (  (  ABS (tran_date_bal)
                                     - FLOOR (ABS (tran_date_bal))
                                    )
                                  * 100
                                 ),
                         2,
                         '0'
                        )
           INTO clsn_bal
           FROM tbaadm.eab a, tbaadm.gam b
          WHERE a.acid = b.acid
            AND b.foracid = facid
            AND a.bank_id = '&5'
            AND b.bank_id = '&5'
            AND a.eod_date <= (edate)
            AND a.eod_date =
                   (SELECT MAX (eod_date)
                      FROM tbaadm.eab e1
                     WHERE e1.acid = a.acid
                       AND e1.bank_id = '&5'
                       AND e1.eod_date <= (edate));
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
--null;
            clsn_bal :=
                  ':62F:'
               || 'C'
               || TO_CHAR (TO_DATE (sdate), 'YYMMDD')
               || acctcrncy
               || 0
               || ','
               || 0
               || 0;
      END;

      DBMS_OUTPUT.put_line (clsn_bal);

--
--MT 940 Statement Close
--
----MT 940 tag 64 -Closing Available Balance(Available Funds)
----This portion was added to take care of effective available balance on the statement
   ---added by PRINCEWILL C OPARA on 30-06-2006
      BEGIN
         SELECT    ':64:'
                || DECODE (SIGN (NVL (value_date_bal, 0)), -1, 'D', 'C')
                || TO_CHAR (TO_DATE (edate), 'YYMMDD')
                || acct_crncy_code
                || TO_CHAR (FLOOR (ABS (value_date_bal)))
                || ','
                || LPAD (TO_CHAR (  (  ABS (value_date_bal)
                                     - FLOOR (ABS (value_date_bal))
                                    )
                                  * 100
                                 ),
                         2,
                         '0'
                        )
           INTO clsn_bal64
           FROM tbaadm.eab a, tbaadm.gam b
          WHERE a.acid = b.acid
            AND b.foracid = facid
            AND a.bank_id = '&5'
            AND b.bank_id = '&5'
            AND a.eod_date <= (edate)
            AND a.eod_date =
                   (SELECT MAX (eod_date)
                      FROM tbaadm.eab e1
                     WHERE e1.acid = a.acid
                       AND e1.bank_id = '&5'
                       AND e1.eod_date <= (edate));
      ---The begin and null exception  statment was added to correct failure when there is null date from --
      ---eab following account closure.This error occurred on 19.09.2006 and corrected 20.09.06
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            clsn_bal64 :=
                  ':64:'
               || 'C'
               || TO_CHAR (TO_DATE (sdate), 'YYMMDD')
               || acctcrncy
               || 0
               || ','
               || 0
               || 0;
      END;

      DBMS_OUTPUT.put_line (clsn_bal64);
--
--MT 940 Statement Close
--
      DBMS_OUTPUT.put_line ('-}');

      --UPDATE tbaadm.gac
      --  SET free_code_9 = seq_date,
      --     free_code_10 = seq_no
      -- WHERE acid = account_id AND bank_id = '&5';
   END;
END;
/

SPOOL off

